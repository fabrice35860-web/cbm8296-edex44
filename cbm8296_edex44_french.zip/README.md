# EDEX 4.4 + matching editor ROM — French Commodore CBM 8296

ROM dumps from a working French CBM 8296 (AZERTY keyboard) fitted with the
EDEX 4.4 BASIC extension by Eristel (1981), together with the screen editor
ROM it runs with.

In 2016 Didier Derny noted on the cbm-hackers list that the EDEX 4.4 image on
zimmers.net was unusable without its matching $E000 editor ROM, which nobody
had. This machine has both, and EDEX 4.4 initialises and runs on it.

## Files

| File | Size | Address | Description |
|---|---|---|---|
| `edex44_A000.bin` | 4096 | $A000-$AFFF | EDEX V4.4 (C) ERISTEL 1981, option ROM socket |
| `editor_E000-E7FF.bin` | 2048 | $E000-$E7FF | Screen editor ROM (UE8), lower part |
| `editor_E900-EFFF.bin` | 1792 | $E900-$EFFF | Screen editor ROM (UE8), upper part |
| `editor_UE8_4K_E800filled_FF.bin` | 4096 | $E000-$EFFF | Full 4K UE8 image, page $E800-$E8FF filled with $FF |
| `tap_EDEX44.tap` | | | Raw TAPuino capture of the EDEX dump |
| `tap_EDITOR.tap` | | | Raw TAPuino capture of the editor dump |

## Checksums

| File | MD5 | SHA1 |
|---|---|---|
| `edex44_A000.bin` | 7a0dded2a91859b6f73a408aa6981e43 | d4bf02217e6b589bf0985ae81a9000119ac781c4 |
| `editor_E000-E7FF.bin` | b46ce066a38a7f23e44dcdd83bc04380 | 69b864babf1600163d900d1f701dd573595c37b7 |
| `editor_E900-EFFF.bin` | a57931f4860242b92cd918900bbf225f | c15c8d8e48e9187fd28a7e30a564b3c26214347c |
| `editor_UE8_4K_E800filled_FF.bin` | 269f84ef2bafb8578eec01dc56844579 | b03d0cce3ff25bbcace9ae801dd6ac9ee862b405 |

## How the dumps were made

The ROMs were read by the CPU on the real machine, not with an EPROM reader:

1. Power-on, EDEX not activated.
2. ROM contents copied to RAM at $3000 from BASIC with PEEK/POKE.
3. RAM saved to tape with the built-in TIM monitor (`.S "...",01,3000,...`),
   recorded with a TAPuino.
4. TAP files decoded with a custom decoder: both copies of every block
   (header and data) are identical, all checksums valid, no pulse errors.

Saving directly from the ROM area with TIM produced only the header blocks;
the copy-to-RAM step was needed.

## Known limitations

- The $E800-$E8FF page of the UE8 editor EPROM is hidden by I/O and could not
  be read. It is filled with $FF in the 4K image; the machine never reads it.
- The French character generator EPROM (label "AZ-E-01 GEN.", PETSCII
  graphics plus accented characters) is not CPU-visible and has not been
  dumped yet.
- Not yet compared byte-for-byte with `edex_4.4_french_a000_ud11.bin` on
  zimmers.net. <!-- update after comparison -->

## EDEX 4.4 usage

Activate with `SYS 40960`, which prints `EDEX V4.4 (C)ERISTEL 1981`.

Keywords found in the ROM's token table:

`IF` `FETCH` `LIST` `AUTO` `FIND` `DUMP` `ERROR` `RENU` `DELETE` `PLOT`
`RESET` `BEEP` `MERGE` `PRINTUSING` `ELSE` `CALL` `TRACE` `OFF` `HARDCOPY`
`SWAP` `KILL`

EDEX-specific error messages include `?BAD FORMAT` and `ELSE WITHOUT IF`.

## Emulation (VICE)

```
xpet -model 8296 -editor editor_UE8_4K_E800filled_FF.bin -romA edex44_A000.bin
```

Then `SYS 40960`. Accented characters will not display correctly until the
French character ROM is dumped.

## Copyright

EDEX is (C) 1981 Eristel; the editor ROM is Commodore firmware. These dumps
are shared for preservation and research only; no licence is granted.

Dumped by Fafa, October 2026.
